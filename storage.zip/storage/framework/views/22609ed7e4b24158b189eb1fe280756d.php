<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rookie record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo e(asset('css/payment.css')); ?>">
</head>
<body>

    <nav class="sticky navbar navbar-expand-lg navbar-dark bg-black">
        <a class="navbar-brand judul word" href="/"><h1>Rookie <br>
            Record
        </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-item nav-link " href="/">Home</a>
       </div>
    </nav>

    <form action="/checkout/{id}"method="post">
<div class="cassette">
    <h2>Payment</h2>
</div>
<?php if(isset($kaset)): ?>
<div class="barangpayment">
    <img src="/gambar/Sonic Youth Black Goo - L.png" alt="" style="width:300px" class="foto">
    <h2 class="harga">Rp.<?php echo e($kaset->harga); ?></h2>

    <div class="deskripsi">
        <h2>Artist: <?php echo e($kaset->artist); ?></h2>
        <h2>Album:<?php echo e($kaset->album); ?></h2>
        <h2>Deskripsi barang:<?php echo e($kaset->deskripsi); ?></h2>
    </div>
<?php elseif(isset($compactdisk)): ?>
    <div class="barangpayment">
        <img src="/gambar/Sonic Youth Black Goo - L.png" alt="" style="width:300px" class="foto">
        <h2 class="harga">Rp.<?php echo e($compactdisk->harga); ?></h2>

        <div class="deskripsi">
            <h2>Artist: <?php echo e($compactdisk->artist); ?></h2>
            <h2>Album:<?php echo e($compactdisk->album); ?></h2>
            <h2>Deskripsi barang:<?php echo e($compactdisk->deskripsi); ?></h2>
        </div>
        <?php endif; ?>


    <?php echo csrf_field(); ?>
    
    <div class="container-biodata">
        <div class="baris1 mt-40">
            <input type="text" class="input-payment" id="name" name="name" placeholder="Your name.."><br><br>
            <input type="number" class="input-payment" id="quantity" name="quantity" placeholder="how much?" min="1"><br><br>
            <input type="text" class="input-payment" id="phone" name="phone" placeholder="Your phone number"><br><br>
            <textarea name="address" class="input-alamat" id="address" name="address" rows="3" placeholder="Your Address"></textarea>
        </div>
        <div class="tombol mt-40">
            <?php if(isset($kaset)): ?>
                <a href="<?php echo e(route('checkout', ['id' => $kaset->id]),); ?>" onclick="showPaymentAlert()">
                    <input type="button and submit"  value="the item">
                    

                </a>
            <?php endif; ?>

            <?php if(isset($compactdisk)): ?>
                <a href="<?php echo e(route('checkout', ['id' => $compactdisk->id]),); ?>" onclick="showPaymentAlert()">
                    <input type="button" value="the item">
                    <input type="submit" value="Payment for Compact Disk">
                </a>
            <?php endif; ?>


        </div>
    </form>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\rookie-record\resources\views/payment.blade.php ENDPATH**/ ?>