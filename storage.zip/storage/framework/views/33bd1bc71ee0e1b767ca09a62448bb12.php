<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- @TODO: replace SET_YOUR_CLIENT_KEY_HERE with your client key -->
    <script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(config('midtrans.client_key')); ?>"></script>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rookie record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/checkout.css')); ?>">
</head>

<body>

    <nav class="sticky navbar navbar-expand-lg navbar-dark bg-black">
        <a class="navbar-brand judul word" href="/"><h1>Rookie <br>
            Record
        </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-item nav-link " href="/">Home</a>
       </div>
    </nav>

    <div class="barangpayment">
        <?php if(isset($kaset)): ?>
        <img src="/gambar/Sonic Youth Black Goo - L.png" alt="" style="width:300px" class="foto">
        <h2 class="harga">Rp.<?php echo e($kaset->harga); ?></h2>
        <div class="deskripsi">
            <h2>Artist: <?php echo e($kaset->artist); ?></h2>
            <h2>Album:<?php echo e($kaset->album); ?></h2>
            <h2>Deskripsi barang:<?php echo e($kaset->deskripsi); ?></h2>
            <?php elseif(isset($compactdisk)): ?>
        <img src="/gambar/Sonic Youth Black Goo - L.png" alt="" style="width:300px" class="foto">
        <h2 class="harga">Rp.<?php echo e($compactdisk->harga); ?></h2>
        <div class="deskripsi">
            <h2>Artist: <?php echo e($compactdisk->artist); ?></h2>
            <h2>Album:<?php echo e($compactdisk->album); ?></h2>
            <h2>Deskripsi barang:<?php echo e($compactdisk->deskripsi); ?></h2>
            <?php else: ?>
        <div class="detail">
            <h5 class="card-title" style="color: white">Detail pesanan</h5>
            <table>
                <tr>
                    <td style="color: white">Nama : <?php echo e($order->name); ?></td>
                </tr>
                <tr>
                    <td style="color: white">Phone : <?php echo e($order->phone); ?></td>
                </tr>
                <tr>
                    <td style="color: white">Address : <?php echo e($order->address); ?></td>
                </tr>
                <tr>
                    <td style="color: white">Quantity : <?php echo e($order->quantity); ?></td>
                </tr>
                <tr>
                    <td style="color: white">Total Harga : <?php echo e($order->total_price); ?></td>
                </tr>
            </table>
            <button class="btn btn-primary" id="pay-button">Bayar Sekarang</button>
        </div>
        <?php endif; ?>
    </div>
    </div>

    <script type="text/javascript">
        // For example trigger on button clicked, or any time you need
        var payButton = document.getElementById('pay-button');
        payButton.addEventListener('click', function () {
            // Trigger snap popup. @TODO: Replace TRANSACTION_TOKEN_HERE with your transaction token
            window.snap.pay('<?php echo e($snapToken); ?>', {
                onSuccess: function (result) {
                    /* You may add your own implementation here */
                    alert("payment success!");
                    console.log(result);
                },
                onPending: function (result) {
                    /* You may add your own implementation here */
                    alert("waiting for your payment!");
                    console.log(result);
                },
                onError: function (result) {
                    /* You may add your own implementation here */
                    alert("payment failed!");
                    console.log(result);
                },
                onClose: function () {
                    /* You may add your own implementation here */
                    alert('you closed the popup without finishing the payment');
                }
            })
        });
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\rookie-record\resources\views/checkout.blade.php ENDPATH**/ ?>